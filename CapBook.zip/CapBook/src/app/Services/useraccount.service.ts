import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import {map,catchError} from 'rxjs/operators';
import { UserAccount } from '../UserInterface/user-account';

@Injectable({
  providedIn: 'root'
})
export class UseraccountService {

  constructor(private httpClient:HttpClient) { }

  public getAllProductsDetails():Observable<string>{
   // return this.httpClient.get<Product[]>('http://localhost:3455/onlineshop/allProductDetails').pipe(catchError(this.handleError));
  return null;
  }
  public acceptUserDetails(firstName:string,lastName:string,emailID:string,dob:string,gender:string,password:string):Observable<string>{
    var data={
        "emailID":emailID,
        "firstName":firstName,
        "lastName":lastName,
        "password":password,
        "gender":gender,
        "dob": dob,
        "friendList": {},
        "friendRequest": {},
        "status": {}
      }
      console.log(123);
    return this.httpClient.post<string>("http://localhost:1555/acceptUserDetails",data,{}).pipe(catchError(this.handleError));
  }
  public getUserAccountDetails(emailID:string):Observable<UserAccount>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<UserAccount>('http://localhost:1555/getUserDetails',{params:params}).pipe(catchError(this.handleError));
  }
  public remove(emailID:string):Observable<string>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.delete<string>('http://localhost:3455/onlineshop/deleteProductDetails',{params:params}).pipe(catchError(this.handleError));
  }
  public sendFriendRequest(senderEmailID:string,receiverEmailID:string):Observable<string>{
    let params1= new HttpParams();
    let params2= new HttpParams();
    params1=params1.set('senderEmailID',senderEmailID);
    params2=params2.set('receiverEmailID',receiverEmailID);
    return this.httpClient.post<string>('http://localhost:1555/sendFriendRequest',{params1:params1,params2:params2}).pipe(catchError(this.handleError));
  }




  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(` Backend returned code ${error.status}, body was: ${error.message}`);
    }else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`);
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`);
    }
  }
}
