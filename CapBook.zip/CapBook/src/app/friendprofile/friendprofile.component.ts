import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { UserAccount } from '../UserInterface/user-account';

@Component({
  selector: 'app-friendprofile',
  templateUrl: './friendprofile.component.html',
  styleUrls: ['./friendprofile.component.css']
})
export class FriendprofileComponent implements OnInit {
  emailID: string;
  message:string;
  userAccountDetails:UserAccount;

  constructor(public router: Router,public userAccountService:UseraccountService) { }

  ngOnInit() {
    this.emailID = localStorage.getItem('token1');
    this.userAccountService.getUserAccountDetails(this.emailID).subscribe (
      userAccountDetails=>{
      this.userAccountDetails=userAccountDetails;
      console.log(this.userAccountDetails.emailID);
      
    },
    errorMessage=>{
      this.message="Email ID does not exist.";
    }
  );
  }
  back() : void{
    console.log("back");
    this.router.navigate(['/homepageComponent']);
  }

}
